
<?php
//index.php
require('header.php');
require('navbar.php');
require('auth.php');
 ?>

<h1 class="Play-Welcome">Welcome To Pop!</h1>

<form>
<div i="lol">

<input type="button" class="btncreate" onclick="location.href='play.php';" value="Create A Game" />
<input type="button"  class="btndisable" disabled value="Join A Game" title ="COMING SOON" /><br>
</div>
</form>


 <?php
 // footer
 require('footer.php');
  ?>
  `11`
