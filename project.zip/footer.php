<?php
 // footer.php
 ?>


<footer>
  Pop! &copy; 2018
</footer>

</body>
</html>
